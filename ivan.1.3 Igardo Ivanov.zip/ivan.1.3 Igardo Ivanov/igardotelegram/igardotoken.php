<?php

$token = "token" ;
$chat_id = "chatid";
?>

